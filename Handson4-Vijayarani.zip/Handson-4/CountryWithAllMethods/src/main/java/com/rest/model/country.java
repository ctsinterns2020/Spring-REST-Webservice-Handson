package com.rest.model;

import javax.validation.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
public class country {
	
	@NotNull
	@Size(min=2,max=2,message="Country code should be 2 characters") 
	    String code;
String name;
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
}
