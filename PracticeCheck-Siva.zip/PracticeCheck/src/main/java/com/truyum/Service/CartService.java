package com.truyum.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truyum.dao.CartDaoCollectionImpl;

@Service
public class CartService {

	@Autowired
	CartDaoCollectionImpl dao;
	
	public Map<String, List> addtoCart(String userId, int menuItemId) {
		return dao.addCartItem(userId, menuItemId);
	}
	
	public Map<String, List> viewCart(String userId) {
		return dao.displayCartItems(userId);
	}
	
	public Map<String, List> deleteCart(String userId, int menuItemId) {
		return dao.deleteCartItems(userId, menuItemId);
	}
}
