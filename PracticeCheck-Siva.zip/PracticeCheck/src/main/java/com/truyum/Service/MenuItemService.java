package com.truyum.Service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truyum.dao.MenuItemDaoCollectionImpl;
import com.truyum.model.MenuItem;

@Service
public class MenuItemService {

	@Autowired
	MenuItemDaoCollectionImpl dao;
	
	public Set getAllItem()
	{
		return dao.getAllItem();
	}
	public MenuItem save(MenuItem obj) {
		return dao.save(obj);
	}
	public MenuItem getMenuItem(String id)
	{
		return dao.getItem(id);
	}
}
