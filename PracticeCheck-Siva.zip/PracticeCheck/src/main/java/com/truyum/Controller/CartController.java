package com.truyum.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truyum.Service.CartService;

@RestController
public class CartController {

	@Autowired
	CartService service;
	
	@PostMapping("/carts/{userId}/{menuItemId}")
	public Map<String, List> addtoCart(@PathVariable String userId,@PathVariable int menuItemId) {
		return service.addtoCart(userId, menuItemId);
	}
	
	@GetMapping("/carts/{userId}")
	public Map<String, List> viewCart(@PathVariable String userId) {
	return service.viewCart(userId);
	}
	
	@DeleteMapping("/carts/{userId}/{menuItemId}")
	public Map<String, List> deleteCart(@PathVariable String userId,@PathVariable int menuItemId) {
		return service.deleteCart(userId, menuItemId);
	}
}
