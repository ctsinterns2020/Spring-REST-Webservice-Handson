package com.truyum.Controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truyum.Service.MenuItemService;
import com.truyum.dao.MenuItemDaoCollectionImpl;
import com.truyum.model.MenuItem;

@RestController
public class MenuItemController {

	@Autowired
	MenuItemService service;
	
	@GetMapping("/menu-items")
	public Set getAllMenuItems()
	{
		return service.getAllItem();
	}
	
	@GetMapping("/menu-items/{id}")
	public MenuItem editMenuItem(@PathVariable String id)
	{
		return service.getMenuItem(id);
	}
	
	@PutMapping("/menu-item")
	public MenuItem modifyMenuItem(@RequestBody MenuItem menuitem) {
		return service.save(menuitem);
	}
	
	
}
