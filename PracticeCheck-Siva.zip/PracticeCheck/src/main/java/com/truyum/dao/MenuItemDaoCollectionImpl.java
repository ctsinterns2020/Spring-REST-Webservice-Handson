package com.truyum.dao;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.truyum.model.MenuItem;

@Component
public class MenuItemDaoCollectionImpl implements MenuItemDao{

	ApplicationContext context = new ClassPathXmlApplicationContext("truyum.xml"); 
	Set<MenuItem> menuitems= (Set<MenuItem>) context.getBean("itemList"); 
	
	
	@Override
	public Set getAllItem() {
		return menuitems;
	}

	@Override
	public MenuItem save(MenuItem object) {
		for(MenuItem item: menuitems) {
			if(item.getId()==object.getId())
			{
				item.setName(object.getName());
				item.setPrice(object.getPrice());
				item.setDateOfLaunch(object.getDateOfLaunch());
				break;
			}
		}

		return object;
	}

	@Override
	public MenuItem getItem(String id)
	{
		for(MenuItem item: menuitems) {
			if(item.getId().equals(id))
			{
				return item;
			}
		}

		return null;
	}
	
	

}
