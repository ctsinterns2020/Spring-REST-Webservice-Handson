package com.truyum.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.truyum.model.MenuItem;

public interface MenuItemDao {

	public Set getAllItem();
	public MenuItem save(MenuItem obj);
	public MenuItem getItem(String id);
}
