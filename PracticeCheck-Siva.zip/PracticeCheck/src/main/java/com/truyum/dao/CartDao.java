package com.truyum.dao;

import java.util.List;
import java.util.Map;

public interface CartDao {

	public Map<String, List> addCartItem(String userId,int menuItemId);
	public Map<String,List> displayCartItems(String userId);
	public Map<String,List> deleteCartItems(String userId,int menuItemId);

	
}
