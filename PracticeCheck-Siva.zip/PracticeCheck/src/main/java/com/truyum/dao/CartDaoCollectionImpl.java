package com.truyum.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.truyum.model.MenuItem;

@Component
public class CartDaoCollectionImpl implements CartDao{

	ApplicationContext context = new ClassPathXmlApplicationContext("truyum.xml"); 
	Set<MenuItem> menuitems= (Set<MenuItem>) context.getBean("itemList"); 
	Map<String,List> map=new LinkedHashMap<String,List>();
	
	@Override
	public Map<String, List> addCartItem(String userId, int menuItemId) {
		
		MenuItem menu=null;
		for(MenuItem item: menuitems) {
			if(item.getId()==menuItemId)
			{
				menu=item;
			}
		}
		if(map.containsKey(userId))
		{
			map.get(userId).add(menu);
		}
		else
		{
			List<MenuItem> cart=new ArrayList<MenuItem>();
			cart.add(menu);
			map.put(userId, cart);
		}
		return map;
	}

	@Override
	public Map<String, List> displayCartItems(String userId) {
		Map<String, List> result = new LinkedHashMap<String, List>() ;
		result.put(userId, map.get(userId));
		return result;
	}

	@Override
	public Map<String, List> deleteCartItems(String userId, int menuItemId) {
		MenuItem menu=null;
		for(MenuItem item: menuitems) {
			if(item.getId()==menuItemId)
			{
				menu=item;
			}
		}
		if(map.containsKey(userId))
		{
			map.get(userId).remove(menu);
		}
		return map;
	}
	

}
