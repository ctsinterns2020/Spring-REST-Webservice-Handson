package com.rest.Exception;

import org.springframework.web.bind.annotation.ResponseStatus;


public class CountryNotFoundException extends RuntimeException{

	String id;
public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
public CountryNotFoundException(String code)
{
	this.id=code;
}
	
	
	
}
