package com.movie.Controller;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.movie.Service.MoviesService;
import com.movie.dao.MoviesDaoImpl;
import com.movie.model.Movies;

@RestController
//@RequestMapping("/menu-item")
public class MovieListController {

	@Autowired
	MoviesService service;
	
	//Admin
	@GetMapping("/movie-list-admin")
	public Set adminMovies()
	{
		return service.adminMovies();
	}
	
	@PutMapping("/movie-list")
	public Movies modifyMovie(@RequestBody Movies movie) {
		return service.save(movie);
	}
	
	
	//Customer
	@GetMapping("/movie-list-customer")
	public Set customerMovies() {
		return service.getAllMoviesCustomer();
	}
	
	@PostMapping("/movie-list-customer/{userId}/{movieId}")
	public String customeFavourites(@PathVariable String userId,@PathVariable int movieId) {
		return service.customeFavourites(userId, movieId);
	}
	
	@GetMapping("/movie-list-customer/{userId}")
	public List<Movies> viewFavouriteMovies(@PathVariable String userId) {
		return service.viewFavouriteMovies(userId);
	}
	
	@DeleteMapping("/movie-list-customer/{userId}/{movieId}")
	public String remove(@PathVariable String userId,@PathVariable int movieId) {
		
		if(service.remove(userId, movieId))
		{
			return "Movie Removed from FavoriteList";
		}
		else
		{
			return "Requested Movie does not exist in your Favorites";
		}
	}
}
