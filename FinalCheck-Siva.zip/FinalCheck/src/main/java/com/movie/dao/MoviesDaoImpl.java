package com.movie.dao;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.movie.model.Movies;

@Component
public class MoviesDaoImpl implements MoviesDao {
	Map<String, List> map = new LinkedHashMap<String, List>();
	
	ApplicationContext context = new ClassPathXmlApplicationContext("movie.xml");
	Set<Movies> admin = (Set<Movies>) context.getBean("itemList");
	Set<Movies> customer = new LinkedHashSet<Movies>();
	
	@Override
	public Set getMovies() {
		return admin;
	}

	@Override
	public Movies save(Movies obj) {
		for (Movies movie : admin) {
			if (movie.getId() == obj.getId()) {
				movie.setName(obj.getName());
				movie.setBoxOffice(obj.getBoxOffice());
				movie.setDateOfRelease(obj.getDateOfRelease());
				return movie;
			}
		}
		return null;
	}

	//Active_Movies
	@Override
	public Set getAllMoviesCustomer() {
		for (Movies movie : admin) {
			if (movie.getActive().equals("yes")) {
				customer.add(movie);
			}
		}
		return customer;
	}

	@Override
	public String customeFavourites(String userId, int movieId) {
		Movies fav = null;
		for (Movies movie : customer) {
			if (movie.getId() == movieId) {
				fav = movie;
			}
		}
		if (map.containsKey(userId)) {
			map.get(userId).add(fav);
		} 
		else {
			List<Movies> watchlist = new ArrayList<Movies>();
			watchlist.add(fav);
			map.put(userId, watchlist);
		}
		return "Your favorite movieslist has been updted";
	}

	@Override
	public List<Movies> favouriteMovies(String userId) {
		return map.get(userId);
	}

	@Override
	public Boolean delete(String userId, int movieId) {
		Movies fav = null;
		for (Movies movie : customer) {
			if (movie.getId() == movieId) {
				fav = movie;
			}
		}
		return map.get(userId).remove(fav);
	}

}
