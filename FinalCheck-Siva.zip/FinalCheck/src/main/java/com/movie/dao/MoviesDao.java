package com.movie.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.movie.model.Movies;

public interface MoviesDao {
	//Admin
	public Set getMovies();
	public Movies save(Movies obj);
	
	//customer
	public Set getAllMoviesCustomer();
	public String customeFavourites(String userId,int movieId);
	public List<Movies> favouriteMovies(String userId);
	public Boolean delete(String userId,int movieId);
}
