package com.movie.Service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.dao.MoviesDaoImpl;
import com.movie.model.Movies;

@Service
public class MoviesService {

	@Autowired
	MoviesDaoImpl dao;
	
	public Set adminMovies()
	{
		return dao.getMovies();
	}
	public Movies save(Movies obj) {
		return dao.save(obj);
	}
	public Set getAllMoviesCustomer() {
		return dao.getAllMoviesCustomer();
	}
	public String customeFavourites(String userId, int movieId) {
		return dao.customeFavourites(userId, movieId);
	}
	public List<Movies> viewFavouriteMovies(String userId) {
		return dao.favouriteMovies(userId);
	}
	public Boolean remove(String userId, int movieId) {
		return dao.delete(userId, movieId);
	}
}
