package com.movie.model;
import java.math.BigDecimal;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class Movies {
	
	
	private int id;
	private String name;
	private BigDecimal BoxOffice;
	private String active;
	private String dateOfRelease;
	private String category;
	public Movies(int id, String name, BigDecimal boxOffice, String active, String dateOfRelease, String category) {
		super();
		this.id = id;
		this.name = name;
		BoxOffice = boxOffice;
		this.active = active;
		this.dateOfRelease = dateOfRelease;
		this.category = category;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getBoxOffice() {
		return BoxOffice;
	}
	public void setBoxOffice(BigDecimal boxOffice) {
		BoxOffice = boxOffice;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getDateOfRelease() {
		return dateOfRelease;
	}
	public void setDateOfRelease(String dateOfRelease) {
		this.dateOfRelease = dateOfRelease;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "MovieList [id=" + id + ", name=" + name + ", BoxOffice=" + BoxOffice + ", active=" + active
				+ ", dateOfRelease=" + dateOfRelease + ", category=" + category + "]";
	}
	public Movies() {
		super();
		// TODO Auto-generated constructor stub
	}

	


}
