package com.handson;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;


@Component
public class EmployeeDao {

	public List getAllEmployee()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("employeeXml.xml"); 
		List<Employee> obj= (List<Employee>) context.getBean("employeeList"); 
		
		System.out.println(obj);
		return obj;
	}
	
}
