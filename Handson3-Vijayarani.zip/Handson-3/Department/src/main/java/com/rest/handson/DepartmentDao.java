package com.rest.handson;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;



@Component
public class DepartmentDao {
	public List getAllDepartment()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("departmentXml.xml"); 
		List<Department> obj= (List<Department>) context.getBean("depList"); 
		
		
		return obj;
	}
	
	
}
