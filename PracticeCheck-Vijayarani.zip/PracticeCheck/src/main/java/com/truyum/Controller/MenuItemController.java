package com.truyum.Controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truyum.Service.MenuItemService;
import com.truyum.dao.MenuItemDaoImpl;
import com.truyum.model.MenuItem;

@RestController
//@RequestMapping("/menu-item")
public class MenuItemController {

	@Autowired
	MenuItemService service;
	
	@GetMapping("/menu-item")
	public Set getAllItem()
	{
		return service.getAllItem();
	}
	
	@GetMapping("/menu-item/{id}")
	public MenuItem editMenuItem(@PathVariable int id)
	{
		Set<MenuItem> items = (Set<MenuItem>) service.getAllItem();
		
		MenuItem obj=new MenuItem();
		
		for(MenuItem item: items) {
			if(item.getId()==id)
				obj=item;
		}
		
		
		return obj;
	}
	
	@PutMapping("/menu-item")
	public MenuItem modifyMenuItem(@RequestBody MenuItem obj) {
		System.out.println("Modify controller");
		return service.save(obj);
	}
	
	
}
