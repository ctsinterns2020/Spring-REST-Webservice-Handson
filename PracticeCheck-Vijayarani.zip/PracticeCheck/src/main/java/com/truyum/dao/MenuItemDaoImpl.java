package com.truyum.dao;

import java.util.List;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.truyum.model.MenuItem;

@Component
public class MenuItemDaoImpl implements MenuItemDao{

	ApplicationContext context = new ClassPathXmlApplicationContext("truyum.xml"); 
	Set<MenuItem> obj= (Set<MenuItem>) context.getBean("itemList"); 
	
	@Override
	public Set getAllItem() {
		return obj;
	}

	@Override
	public MenuItem save(MenuItem object) {
		for(MenuItem item: obj) {
			if(item.getId()==object.getId())
			{
				item.setName(object.getName());
				item.setPrice(object.getPrice());
				item.setDateOfLaunch(object.getDateOfLaunch());
				break;
			}
		}
		
		
		
		//System.out.println(obj);
		return object;
	}

}
