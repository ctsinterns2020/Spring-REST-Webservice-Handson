package com.truyum.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.truyum.model.MenuItem;

@Component
public class CartDaoImpl implements CartDao{

	
	Map<String,List> map=new LinkedHashMap<String,List>();
	
	ApplicationContext context = new ClassPathXmlApplicationContext("truyum.xml"); 
	Set<MenuItem> obj= (Set<MenuItem>) context.getBean("itemList"); 
	
	
	@Override
	public String addtoCart(String userId, int menuItemId) {
		
		MenuItem menu=null;
		for(MenuItem item: obj) {
			if(item.getId()==menuItemId)
			{
				menu=item;
			}
		}
		if(map.containsKey(userId))
		{
			map.get(userId).add(menu);
		}
		else
		{
			List<MenuItem> cart=new ArrayList<MenuItem>();
			cart.add(menu);
			map.put(userId, cart);
		}
		return "Item added to Cart";
	}

	@Override
	public Map<String, List> viewCart(String userId) {
		
		Map<String, List> result = new LinkedHashMap<String, List>() ;
		
		result.put(userId, map.get(userId));
		
		return result;
	}

	@Override
	public Map<String, List> deleteCart(String userId, int menuItemId) {
		// TODO Auto-generated method stub
		MenuItem menu=null;
		for(MenuItem item: obj) {
			if(item.getId()==menuItemId)
			{
				menu=item;
			}
		}
		if(map.containsKey(userId))
		{
			map.get(userId).remove(menu);
		}
		return map;
	}

}
