package com.truyum.dao;

import java.util.List;
import java.util.Map;

public interface CartDao {

	public String addtoCart(String userId,int menuItemId);
	public Map<String,List> viewCart(String userId);
	public Map<String,List> deleteCart(String userId,int menuItemId);
	
}
