package com.truyum.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truyum.dao.CartDaoImpl;

@Service
public class CartService {

	@Autowired
	CartDaoImpl dao;
	
	public String addtoCart(String userId, int menuItemId) {
		return dao.addtoCart(userId, menuItemId);
	}
	
	public Map<String, List> viewCart(String userId) {
		return dao.viewCart(userId);
	}
	
	public Map<String, List> deleteCart(String userId, int menuItemId) {
		return dao.deleteCart(userId, menuItemId);
	}
}
