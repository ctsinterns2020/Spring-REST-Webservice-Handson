package com.truyum.Service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truyum.dao.MenuItemDaoImpl;
import com.truyum.model.MenuItem;

@Service
public class MenuItemService {

	@Autowired
	MenuItemDaoImpl dao;
	
	public Set getAllItem()
	{
		return dao.getAllItem();
	}
	public MenuItem save(MenuItem obj) {
		return dao.save(obj);
	}
}
