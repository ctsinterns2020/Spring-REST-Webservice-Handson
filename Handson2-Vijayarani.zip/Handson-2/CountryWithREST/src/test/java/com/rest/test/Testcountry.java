package com.rest.test;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.rest.controller.*;

@SpringBootTest
public class Testcountry {
	@Autowired 
	private countryController countryController; 

	@Test 
	public void contextLoads() { 
	assertNotNull(countryController);
	} 

}
