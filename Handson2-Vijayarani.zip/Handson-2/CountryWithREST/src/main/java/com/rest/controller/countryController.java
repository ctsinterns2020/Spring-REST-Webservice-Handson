package com.rest.controller;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;

import com.rest.Exception.*;
import com.rest.Exception.Error;
import com.rest.model.country;

@RestController
public class countryController {

	@GetMapping("/country")
	public country getCountry()
	{
		
		ApplicationContext context = new ClassPathXmlApplicationContext("countryXml.xml"); 
		country obj=(country) context.getBean("object"); 
		
		return obj;
	}
	
	@GetMapping("/countries")
	public List<country> getAllCountry()
	{
		
		ApplicationContext context = new ClassPathXmlApplicationContext("countryXml.xml"); 
		List<country> obj= (List<country>) context.getBean("countryList"); 
		
		return obj;
	}
	
	@GetMapping("/country/{code}")
	public country getOneCountry(@PathVariable String code)throws CountryNotFoundException
	{
		
		ApplicationContext context = new ClassPathXmlApplicationContext("countryXml.xml"); 
		List<country> obj= (List<country>) context.getBean("countryList"); 
		
		
		country object=new country();
		
		for(country con:obj)
		{
			
			if(con.getCode().equals(code))
			{
				object=con;
			}
			
		}
		
		if(object.getCode()==null)
		{
			throw new CountryNotFoundException(code);
		}
		
		return object;
	}
	
	@ExceptionHandler(CountryNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND) 
	public Error countryNotFound(CountryNotFoundException e) {
		
		String id = e.getId();
		
		return new Error(id,"Country not found");
		
		
	}
	
	
	
	
}
