package com.movie.Service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.dao.MovieListDaoImpl;
import com.movie.model.MovieList;

@Service
public class MovieListService {

	@Autowired
	MovieListDaoImpl dao;
	
	public Set getAllMovie()
	{
		return dao.getAllMovie();
	}
	public MovieList save(MovieList obj) {
		return dao.save(obj);
	}
	public Set getMovieCustomer() {
		return dao.getMovieCustomer();
	}
	public String addtoFavourite(String userId, int movieId) {
		return dao.addtoFavourite(userId, movieId);
	}
	public Map<String, List> viewFavouriteList(String userId) {
		return dao.viewFavouriteList(userId);
	}
	public Map<String, List> deleteMovie(String userId, int movieId) {
		return dao.deleteMovie(userId, movieId);
	}
}
