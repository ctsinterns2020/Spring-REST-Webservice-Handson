package com.movie.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.movie.model.MovieList;

public interface MovieListDao {

	public Set getAllMovie();
	public MovieList save(MovieList obj);
	public Set getMovieCustomer();
	public String addtoFavourite(String userId,int movieId);
	public Map<String,List> viewFavouriteList(String userId);
	public Map<String,List> deleteMovie(String userId,int movieId);
}
