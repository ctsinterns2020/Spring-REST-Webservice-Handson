package com.movie.dao;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.movie.model.MovieList;



@Component
public class MovieListDaoImpl implements MovieListDao{
	Map<String,List> map=new LinkedHashMap<String,List>();
	
	ApplicationContext context = new ClassPathXmlApplicationContext("movie.xml"); 
	Set<MovieList> obj= (Set<MovieList>) context.getBean("itemList"); 
	
	Set<MovieList> customer=new LinkedHashSet<MovieList>();
		
	@Override
	public Set getAllMovie() {
		return obj;
	}

	@Override
	public MovieList save(MovieList object) {
		for(MovieList item: obj) {
			if(item.getId()==object.getId())
			{
				item.setName(object.getName());
				item.setBoxOffice(object.getBoxOffice());
				item.setDateOfRelease(object.getDateOfRelease());
				break;
			}
		}
		return object;
	}

	@Override
	public Set getMovieCustomer() {
		for(MovieList object:obj)
		{
			if(object.getActive().equals("yes"))
			{
			customer.add(object);	
			}
		}
		return customer;
	}

	@Override
	public String addtoFavourite(String userId, int movieId) {
		MovieList movie=null;
		for(MovieList list: customer) {
			if(list.getId()==movieId)
			{
				movie=list;
			}
		}
		if(map.containsKey(userId))
		{
			map.get(userId).add(movie);
		}
		else
		{
			List<MovieList> cart=new ArrayList<MovieList>();
			cart.add(movie);
			map.put(userId, cart);
		}
		return "Movie added to Favourite List";
	}

	@Override
	public Map<String, List> viewFavouriteList(String userId) {
Map<String, List> result = new LinkedHashMap<String, List>() ;
		
		result.put(userId, map.get(userId));
		
		return result;
	}

	@Override
	public Map<String, List> deleteMovie(String userId, int movieId) {
		MovieList movie=null;
		for(MovieList list: obj) {
			if(list.getId()==movieId)
			{
				movie=list;
			}
		}
		if(map.containsKey(userId))
		{
			map.get(userId).remove(movie);
		}
		return map;
	}

}
