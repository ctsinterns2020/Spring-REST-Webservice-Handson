package com.movie.model;
import java.math.BigDecimal;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class MovieList {
	
	
	private int id;
	private String name;
	private BigDecimal BoxOffice;
	private String active;
	private String dateOfRelease;

	public String getDateOfRelease() {
		return dateOfRelease;
	}

	public void setDateOfRelease(String dateOfRelease) {
		this.dateOfRelease = dateOfRelease;
	}

	private String category;
	
	public BigDecimal getBoxOffice() {
		return BoxOffice;
	}

	public void setBoxOffice(BigDecimal boxOffice) {
		BoxOffice = boxOffice;
	}

	
	
	public MovieList() {
		
	}

	public MovieList(Integer id, String name, BigDecimal price, String active, String dateOfLaunch, 
			String category, String freeDelivery) {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}


}
