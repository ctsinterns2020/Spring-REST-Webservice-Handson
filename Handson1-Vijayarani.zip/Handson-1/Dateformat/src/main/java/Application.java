import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application {
public static void main(String[] args)
{
	ApplicationContext context = new ClassPathXmlApplicationContext("DateFormat.xml"); 
	SimpleDateFormat format = context.getBean("dateFormat", SimpleDateFormat.class); 
	
	try {
		System.out.println(format.parse("25/02/2020"));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}
}
