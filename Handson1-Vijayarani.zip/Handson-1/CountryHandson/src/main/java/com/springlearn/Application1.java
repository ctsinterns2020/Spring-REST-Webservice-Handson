package com.springlearn;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application1 {
	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContent.xml"); 
		List<country> format = (List<country>) context.getBean("countryList"); 
		
		for(country obj:format)
		{
			System.out.println(obj.getCode()+" "+obj.getName());
		}
		
		
}
}
