package com.rest.log;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 


@SpringBootApplication
public class Application3 {


		private static final Logger LOGGER = LoggerFactory.getLogger(Application3.class);
		public static String date="25/02/2020";
		
	public static void main(String[] args) {
		
		SpringApplication.run(Application3.class, args);
		
		displayDate();
		}
		
		
		

		public static void displayDate() { 
		
		LOGGER.info("START"); 
			
	LOGGER.debug(date); 
			
	LOGGER.info("END"); 
			} 

	}


